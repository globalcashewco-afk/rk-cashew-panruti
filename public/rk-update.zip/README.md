# RK Cashew update (for Codespaces)

Files:
- worker.js           -> replace your Worker file (same path as "main" in wrangler.toml)
- public/index.html   -> replace your index.html (the [assets] directory in wrangler.toml)
- schema.sql          -> only for a NEW orders table (skip if you already have one)

Steps:
1. Unzip in the repo root and overwrite: unzip -o rk-update.zip
2. New orders table:  npx wrangler d1 execute <DB_NAME> --remote --file=schema.sql
   Existing table: needs columns id, name, phone, address, items, total, utr, status, tracking, screenshot, created_at
   and run: CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_utr ON orders(utr);
3. Admin password:  npx wrangler secret put ADMIN_TOKEN
4. wrangler.toml needs: [[d1_databases]] binding = "DB", and [assets] directory = "./public" binding = "ASSETS"
5. Edit PRODUCTS (grades/prices) at the top of worker.js.
6. Deploy: npx wrangler deploy      Admin: https://<your-site>/#admin
Keep rk-favicon.svg and apple-touch-icon.png inside public/.
