// RK Cashew Panruti - Cloudflare Worker (D1)
// Bindings: DB (D1), ASSETS (static assets), secret ADMIN_TOKEN, optional SCREENSHOTS (R2 bucket)
// Statuses: UNPAID, PAID, PACKED, SHIPPED, CANCELLED

// TODO: replace with your real grades and prices (INR per kg). Prices are enforced here, server-side.
const PRODUCTS = [
  { id: 'w320', name: 'W320 Whole Cashew', price: 900 },
  { id: 'w240', name: 'W240 Premium Cashew', price: 1000 },
  { id: 'lwp', name: 'LWP Large White Pieces', price: 750 },
];
const STATUSES = ['UNPAID', 'PAID', 'PACKED', 'SHIPPED', 'CANCELLED'];

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

const badUtr = (u) =>
  !/^\d{12}$/.test(u) ||
  /^(\d)\1{11}$/.test(u) ||
  '0123456789012345678901234567890'.includes(u) ||
  '9876543210987654321098765432109'.includes(u);

function newId() {
  const d = new Date();
  const yymmdd = String(d.getFullYear()).slice(2) + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
  return 'RK' + yymmdd + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
}

function isAdmin(request, env) {
  const t = (request.headers.get('Authorization') || '').replace('Bearer ', '');
  return !!env.ADMIN_TOKEN && t.length > 0 && t === env.ADMIN_TOKEN;
}

async function createOrder(request, env) {
  let form;
  try { form = await request.formData(); } catch { return json({ error: 'Invalid request.' }, 400); }

  const name = String(form.get('name') || '').trim().slice(0, 80);
  let phone = String(form.get('phone') || '').replace(/\D/g, '');
  if (phone.length === 12 && phone.startsWith('91')) phone = phone.slice(2);
  const address = String(form.get('address') || '').trim().slice(0, 300);
  const utr = String(form.get('utr') || '').trim();
  const file = form.get('screenshot');

  if (!name || !/^\d{10}$/.test(phone) || !address) return json({ error: 'Name, 10-digit phone and address are required.' }, 400);
  if (badUtr(utr)) return json({ error: 'Enter a valid 12-digit UTR.' }, 400);
  if (!file || typeof file === 'string' || !['image/jpeg', 'image/png'].includes(file.type) || file.size < 10240 || file.size > 5242880)
    return json({ error: 'Upload a JPG/PNG payment screenshot (10 KB - 5 MB).' }, 400);

  // Rebuild items and total from the server-side price list (never trust client prices)
  let raw;
  try { raw = JSON.parse(form.get('items') || '[]'); } catch { return json({ error: 'Invalid items.' }, 400); }
  const items = [];
  let total = 0;
  for (const p of PRODUCTS) {
    const qty = Number((raw.find((r) => r.id === p.id) || {}).qty || 0);
    if (!Number.isInteger(qty) || qty < 0 || qty > 100) return json({ error: 'Invalid quantity.' }, 400);
    if (qty > 0) { items.push({ id: p.id, name: p.name, qty, price: p.price }); total += qty * p.price; }
  }
  if (!items.length) return json({ error: 'Please select at least one item.' }, 400);

  // Automatic duplicate UTR check
  const dup = await env.DB.prepare('SELECT id FROM orders WHERE utr = ?').bind(utr).first();
  if (dup) return json({ error: 'This UTR number has already been used.' }, 400);

  const id = newId();
  let shot = null;
  if (env.SCREENSHOTS) {
    shot = `${id}.${file.type === 'image/png' ? 'png' : 'jpg'}`;
    await env.SCREENSHOTS.put(shot, await file.arrayBuffer(), { httpMetadata: { contentType: file.type } });
  }
  try {
    await env.DB.prepare(
      "INSERT INTO orders (id, name, phone, address, items, total, utr, status, screenshot) VALUES (?, ?, ?, ?, ?, ?, ?, 'UNPAID', ?)"
    ).bind(id, name, phone, address, JSON.stringify(items), total, utr, shot).run();
  } catch (e) {
    // The UNIQUE index catches a simultaneous duplicate
    if (String(e).includes('UNIQUE')) return json({ error: 'This UTR number has already been used.' }, 400);
    return json({ error: 'Could not save order. Please try again.' }, 500);
  }
  return json({ id, total, items, status: 'UNPAID' });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    if (path === '/api/products' && request.method === 'GET') return json(PRODUCTS);
    if (path === '/api/orders' && request.method === 'POST') return createOrder(request, env);

    if (path.startsWith('/api/admin/')) {
      if (!isAdmin(request, env)) return json({ error: 'Unauthorized' }, 401);

      if (path === '/api/admin/orders' && request.method === 'GET') {
        const { results } = await env.DB.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 500').all();
        return json(results);
      }
      const m = path.match(/^\/api\/admin\/orders\/([A-Z0-9]+)\/status$/);
      if (m && request.method === 'POST') {
        const body = await request.json().catch(() => ({}));
        const status = String(body.status || '').toUpperCase();
        if (!STATUSES.includes(status)) return json({ error: 'Invalid status.' }, 400);
        const tracking = body.tracking ? String(body.tracking).slice(0, 300) : null;
        const r = await env.DB.prepare('UPDATE orders SET status = ?, tracking = COALESCE(?, tracking) WHERE id = ?')
          .bind(status, tracking, m[1]).run();
        if (!r.meta.changes) return json({ error: 'Order not found.' }, 404);
        return json({ ok: true });
      }
      return json({ error: 'Not found' }, 404);
    }

    if (path.startsWith('/api/')) return json({ error: 'Not found' }, 404);
    return env.ASSETS.fetch(request); // serves index.html and static files
  },
};
