-- Run once: wrangler d1 execute <DB_NAME> --remote --file=schema.sql
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT,
  items TEXT NOT NULL,
  total INTEGER NOT NULL,
  utr TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'UNPAID',
  tracking TEXT,
  screenshot TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
-- Race-proof duplicate protection (two simultaneous orders cannot share a UTR)
CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_utr ON orders(utr);
